#include <stdio.h>
#include <unistd.h>

void win(void)
{
    FILE *f = fopen("flag.txt", "r");
    char flag[128];

    if (!f) {
        puts("Flag file is missing.");
        return;
    }

    if (fgets(flag, sizeof(flag), f))
        printf("You found it! %s", flag);

    fclose(f);
}

void vulnerable(void)
{
    char name[32];

    puts("Welcome to Byte Overflow!");
    puts("Enter your name:");
    read(STDIN_FILENO, name, 256);
    puts("Thanks!");
}

int main(void)
{
    vulnerable();
    return 0;
}
