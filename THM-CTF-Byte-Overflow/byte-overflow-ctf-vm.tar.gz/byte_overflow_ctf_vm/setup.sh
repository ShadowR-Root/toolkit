#!/bin/bash
set -e

# Beginner-friendly 64-bit Linux pwn challenge.
# Run this script inside a Linux VM from this directory.

gcc -O0 -fno-stack-protector -no-pie challenge.c -o byteoverflow

chmod 444 flag.txt
chmod 755 byteoverflow

echo
printf '[+] Built: byteoverflow\n'
printf '[+] Try: ./byteoverflow\n'
printf '[+] Inspect: file byteoverflow\n'
printf '[+] Inspect protections: checksec --file=byteoverflow (if installed)\n'
printf '[+] Find win(): nm -n byteoverflow | grep " win$"\n'
