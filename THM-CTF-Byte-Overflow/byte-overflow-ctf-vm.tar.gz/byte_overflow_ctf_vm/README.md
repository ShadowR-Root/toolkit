# Byte Overflow — Beginner Pwn CTF VM Pack

A tiny, local-only binary-exploitation challenge designed for beginners.

## Intended learning path

1. Notice that `read()` accepts more bytes than the `name` buffer can hold.
2. Use GDB and a cyclic pattern to find the saved return-address offset.
3. Confirm control of RIP with a dummy value.
4. Find the address of `win()`.
5. Build a ret2win payload and recover the flag.

## VM setup

Use an isolated Linux VM (Ubuntu, Debian, Kali, etc.). Copy this folder into the VM, then run:

```bash
./setup.sh
```

The challenge is intentionally built without stack canaries and PIE so the first exploit can focus on the core buffer-overflow idea.

## Creator notes

- Keep the VM isolated from the public network when testing.
- The flag is outside the binary in `flag.txt`, so `strings byteoverflow` should not directly reveal it.
- The player is expected to discover `win()` during analysis rather than being told its address.
- This first room should stop at ret2win; save ASLR bypasses, NX workarounds, ROP chains, and shellcode for later rooms.

## Files

- `challenge.c` — vulnerable source
- `flag.txt` — challenge flag
- `setup.sh` — compiler/setup script
